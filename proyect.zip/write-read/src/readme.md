Repositorio con un programa muy simple en Java para lectura y escritura de ficheros.

Read permite recuperar el 'descriptor' de un fichero y usarlo para leer líneas del mismo.
Write permite escribir en un archivo existente (al final del mismo) o crear un archivo nuevo y escribir en él.


Todo ello desde una clase principal menú.

El .zip presente en el repositorio es el proyecto en Eclipse, para que sea más facil importalo.
